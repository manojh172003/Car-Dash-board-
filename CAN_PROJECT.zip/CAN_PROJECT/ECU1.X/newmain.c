#include "main.h"
#include "keypad.h"
#include "clcd.h"
#include "can.h"
#include "adc.h"
#include "ssd.h"
#include<stdio.h>

static unsigned char ssd[MAX_SSD_CNT];
static unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE,BLANK,BLANK};

unsigned int speed=0;
unsigned char gear=0;

/* delay 1ms function */
/*void delay(unsigned short factor)
{
	unsigned short i, j;

	for (i = 0; i < factor; i++)
	{
		for (j = 500; j--; );
	}
}*/


void init_config(void)
{
	/* Initialize Matrix Keypad */    
    init_digital_keypad();
    
    init_ssd_control();
    
	/* Initialize CAN module */
	init_can();
    
    init_adc();
}

void gear_change()
{
    unsigned char key = read_digital_keypad(STATE_CHANGE);
    if(key==SWITCH1)
    {
        if(gear<6)
            gear++;
    }
    else if(key==SWITCH2)
    {
        if(gear>0)
            gear--;
    } 
}

void can_demo(void)
{
    
    speed = read_adc(4);
    
    speed=speed/10.23;
    
    
    ssd[3]=digit[gear];
    ssd[2]=digit[speed%10];
    ssd[1]=digit[(speed/10)%10];
    ssd[0]=digit[(speed/100)%10];
    display(ssd);

    
    gear_change();
    
	can_transmit();
    int delay=0;
    if(delay++==200)
    {
        delay=0;
    }
    //delay(200);
}

void main(void)
{    
	init_config();

	while (1)
	{
		can_demo();	
	}
}