/*
 * File:   ssd_display.c
 * Author: manoj
 *
 * Created on 8 December, 2025, 7:50 AM
 */


#include <xc.h>
#include "ssd.h"


#define _XTAL_FREQ 20000000
void init_ssd_control()
{
    TRISD=0x00;
    TRISA=TRISA&0xF0;
    SSD_CNT_PORT=SSD_CNT_PORT&0xF0;
}
void display(unsigned char *data)
{
    unsigned char digit;
    
    for(digit=0;digit<MAX_SSD_CNT;digit++)
    {
        SSD_DATA_PORT=data[digit];
        SSD_CNT_PORT = (SSD_CNT_PORT & 0xF0) | (1 << digit); // Select digit
        __delay_us(500);
    }
}
