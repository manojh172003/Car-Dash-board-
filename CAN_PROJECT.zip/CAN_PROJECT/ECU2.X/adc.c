/*
 * File:   adc.c
 * Author: manoj
 *
 * Created on 28 January, 2026, 11:48 AM
 */


#include <xc.h>
#include "adc.h"

#define _XTAL_FREQ 20000000
void init_adc()
{
    ADFM=1;
    
    ACQT0=0;
    ACQT1=1;
    ACQT2=0;
    
    ADCS0=0;
    ADCS1=1;
    ADCS2=0;
    
    ADRESH=0;
    ADRESL=0;
    
    ADON=1;
}

unsigned int read_adc(unsigned char channel)
{
    ADCON0&=0xC3;
    ADCON0 |= (channel<<2);
    __delay_us(20);
    GO=1;
    while(GO);
    return ((unsigned int)ADRESH<<8) | ADRESL;
}