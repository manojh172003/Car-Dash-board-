#ifndef ADC_H
#define ADC_H
void init_adc(void);
unsigned int read_adc(unsigned char channel);
#endif