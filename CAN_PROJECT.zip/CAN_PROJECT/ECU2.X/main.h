#ifndef MAIN_H
#define MAIN_H

#include <xc.h>

#define RPM_MSG_ID   0x120   // single CAN ID used everywhere

#define _XTAL_FREQ 8000000

#define IND_OFF     0
#define IND_LEFT    1
#define IND_RIGHT   2

#define TRUE    1
#define FALSE   0

#define LEFT_LED   LATBbits.LATB0
#define RIGHT_LED  LATBbits.LATB1

#define FORWARD_ID  0x200


#endif
