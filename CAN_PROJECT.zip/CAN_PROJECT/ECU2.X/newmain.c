/*
 * File:   newmain.c
 * Author: manoj
 *
 * Created on 28 January, 2026, 11:35 AM
 */


#include <xc.h>
#include "main.h"
#include "adc.h"
#include "keypad.h"
#include "can.h"


unsigned int rpm = 0;
unsigned char key = 0xFF;
unsigned char indicator = IND_OFF;

void init_config()
{
    init_adc();
    init_can();
    init_digital_keypad();
    
}


void main(void) 
{
    init_config();
    
    unsigned int prev=0;
    int delay =0;
    
    while(1)
    {
    /* -------- KEYPAD -------- */
    unsigned char k = read_digital_keypad(STATE_CHANGE);

    if(k != 0xFF)
    {
        if(k == SWITCH1)          // 1st switch
            indicator = IND_LEFT;
        else if(k == SWITCH2)     // 2nd switch
            indicator = IND_RIGHT;
    }

    /* -------- INDICATOR BLINK -------- */
    if(indicator == IND_LEFT)
    {
        LEFT_LED = 1;
        RIGHT_LED = 0;
        if(delay++==300)
        {
            delay=0;
        }
        LEFT_LED = 0;
        if(delay++==300)
        {
            delay=0;
        }
    }
    else if(indicator == IND_RIGHT)
    {
        RIGHT_LED = 1;
        LEFT_LED = 0;
        if(delay++==300)
        {
            delay=0;
        }
        RIGHT_LED = 0;
        if(delay++==300)
        {
            delay=0;
        }
    }
    else
    {
        LEFT_LED = 0;
        RIGHT_LED = 0;
    }

    /* -------- ADC ? RPM (0?6000) -------- */
    unsigned int adc_val = read_adc(4);

    /* PURE INTEGER MATH */
    rpm = (adc_val * 6000) / 1023;

    /* -------- CAN TRANSMIT -------- */
    can_payload[DLC] = 3;          // Sending 3 bytes

    can_payload[D0]  = indicator; // Indicator state
    can_payload[D1]  = rpm >> 8;  // RPM MSB
    can_payload[D2]  = rpm & 0xFF;// RPM LSB

    can_transmit();
     // RPM LSB

    can_transmit();
    }
 
}