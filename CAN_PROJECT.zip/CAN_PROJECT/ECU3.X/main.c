#include "main.h"
#include "clcd.h"
#include "can.h"
#include<stdio.h>

const char gears[][5]={"N","1","2","3","4","5","R"};
const char indicators[][5]={"<-","->","<->","OFF"};
unsigned int blink=1;
unsigned int speed=0;
unsigned int rpm=0;

/* delay 1ms function */
void delay(unsigned short factor)
{
	unsigned short i, j;

	for (i = 0; i < factor; i++)
	{
		for (j = 500; j--; );
	}
}


void init_config(void)
{
    
    init_clcd();
	/* Initialize CAN module */
	init_can();
    
    delay(200);
    clcd_print("SPD",LINE1(0));
    clcd_print("GEAR",LINE1(4));
    clcd_print("RPM",LINE1(9));
    clcd_print("IND",LINE1(13));  
    
}

void can_demo(void)
{
         
    if (can_receive())
	{		
        unsigned int rx_id;
        rx_id=((can_payload[SIDH]<<3) | 
                (can_payload[SIDL]>>5)); 
        
        if(rx_id == 0x120)
        {
            char res[4];
            speed =can_payload[D0];
            sprintf(res,"%3d",speed);
            clcd_print(res,LINE2(0));
            int idx=can_payload[D1];
            clcd_print(gears[idx],LINE2(5));     
        }
        else if(rx_id == 0x124)
        {
            char temp[5];
            rpm = ((unsigned int)can_payload[D0] << 8) | can_payload[D1];
            sprintf(temp,"%4d",rpm);
            rpm=0;
            clcd_print(temp,LINE2(7));
            if(blink)
            {
                blink=!blink;
                switch(can_payload[D2])
                {
                    case 0x07 : clcd_print("    ",LINE2(12));
                                clcd_print("OFF",LINE2(12));
                                break;
                                
                    case 0x0E : clcd_print("    ",LINE2(12));
                                clcd_print("<-",LINE2(12));
                                break;
                                
                    case 0x0D : clcd_print("    ",LINE2(12));
                                clcd_print("->",LINE2(12));
                                break;  
                                
                    case 0x0B : clcd_print("    ",LINE2(12));
                                clcd_print("<-->",LINE2(12));
                                break;             
                }
            }
            else
            {
                blink=!blink;
                clcd_print("    ",LINE2(12));
            } 
        }  
	}
    
    
}

void main(void)
{    
	init_config();

	while (1)
	{
		can_demo();	
	}
}